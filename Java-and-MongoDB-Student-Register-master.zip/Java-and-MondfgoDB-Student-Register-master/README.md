# Java-and-MongoDB-Student-Register
Menu Driven Student Register in Java with Backend as Mongo DB


Youtbe Playlist - https://www.youtube.com/playlist?list=PL5YAGuaTJoW9PmhYNEbrkKngS0q6MqEHY
